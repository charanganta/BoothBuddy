# System design

```mermaid
flowchart TB
  B[Browser: HTML, CSS, ES modules, observable store] -->|HTTPS JSON| M
  subgraph API[Express app: createApp]
    M[helmet, logging, rate limit, same-origin check, session] --> R[Routes: HTTP only]
    R --> V[Zod validation]
    V --> S[Services: business rules]
  end
  S --> D[(SQLite: users, progress, stations, practice_audit)]
  M --> SS[(Session store: SQLite, swappable)]
```

## Layers
- **Routes** translate HTTP to service calls and nothing else.
- **Services** hold rules and SQL; they receive the database as an argument, so storage can be swapped.
- **Middleware** covers auth, validation, CSRF origin check, rate limiting and the central error handler (`{ error, code, details? }`).
- `createApp({ db, sessionStore, limits })` is the composition root, which keeps tests fast and isolated.

## Privacy model for the simulator
`POST /api/votes` validates the candidate and discards it. `practice_audit` has no user id, candidate or timestamp, and each row is hash-chained to the previous one. `GET /api/votes/audit` recomputes the chain and reports the first broken entry.

## Scaling path
| Limit today | Next step |
|---|---|
| SQLite single writer | WAL mode already on; move services to Postgres (only `src/db.js` and the prepared statements change) |
| Sessions in SQLite file | Add a Redis store in `src/sessionStore.js` and set `SESSION_STORE=redis` |
| In-process rate limits | Use `rate-limit-redis` so counters are shared between instances |
| One Node process | Run several containers (see `Dockerfile`) behind a load balancer; `trust proxy` is already set for production |
| Static assets from Node | Serve `public/` from a CDN; station responses already send `Cache-Control` |
