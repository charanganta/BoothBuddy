
// BoothBuddy CivicQuest - complete browser demo
"use strict";

/* STORAGE */

const STORAGE = {
  profile: "boothBuddyLearnerProfile",
  session: "boothBuddyLoggedIn",
  progress: "boothBuddyProgress",
  theme: "boothBuddyTheme"
};

const defaultProgress = {
  xp: 0,
  bestScore: 0,
  completedLessons: [],
  badges: [],
  practiceVoteDone: false,
  certificateCreated: false
};

function readJSON(key, fallback) {
  try {
    const value = JSON.parse(localStorage.getItem(key));
    return value ?? fallback;
  } catch {
    return fallback;
  }
}

let progress = {
  ...defaultProgress,
  ...readJSON(STORAGE.progress, {})
};

let quizTimer = null;
let currentQuestion = 0;
let score = 0;
let selectedAnswer = false;
let timeLeft = 900;
let quizFinished = false;

/* QUIZ QUESTIONS */

const questions = [
  {
    question: "What is the minimum voting age in India?",
    options: ["16 years", "18 years", "21 years", "25 years"],
    answer: 1,
    explanation: "The voting age for eligible Indian citizens is 18 years."
  },
  {
    question: "What is the main purpose of voting?",
    options: ["To choose representatives", "To pay taxes", "To get a job", "To travel"],
    answer: 0,
    explanation: "Voting lets eligible citizens choose their representatives."
  },
  {
    question: "What does EVM stand for?",
    options: ["Election Vote Method", "Electronic Voting Machine", "Easy Voter Method", "Election Value Machine"],
    answer: 1,
    explanation: "EVM stands for Electronic Voting Machine."
  },
  {
    question: "What should you do before election day?",
    options: ["Ignore your details", "Check your voter information", "Share rumours", "Skip registration"],
    answer: 1,
    explanation: "Checking your voter details in advance helps you prepare."
  },
  {
    question: "Should someone pressure you to vote for a candidate?",
    options: ["Yes", "No", "Only friends", "Only family"],
    answer: 1,
    explanation: "Your voting choice should be your own."
  },
  {
    question: "What is a secret ballot?",
    options: ["A private vote", "A public speech", "A campaign", "A meeting"],
    answer: 0,
    explanation: "A secret ballot protects the privacy of your vote."
  },
  {
    question: "What does NOTA mean?",
    options: ["None of the Above", "Name of the Applicant", "National Office", "None of these Areas"],
    answer: 0,
    explanation: "NOTA means None of the Above."
  },
  {
    question: "Who conducts elections in India?",
    options: ["Election Commission of India", "Supreme Court", "Local schools", "Private companies"],
    answer: 0,
    explanation: "The Election Commission of India conducts elections under its constitutional authority."
  },
  {
    question: "What should you do with election misinformation?",
    options: ["Share it quickly", "Check reliable sources", "Believe every post", "Ignore all facts"],
    answer: 1,
    explanation: "Always check claims with trustworthy sources."
  },
  {
    question: "Can eligible voters choose NOTA where it is available?",
    options: ["Yes", "No", "Only online", "Only during local elections"],
    answer: 0,
    explanation: "NOTA is available on Indian EVM ballots."
  },
  {
    question: "What is a voter list?",
    options: ["List of eligible registered voters", "List of candidates' hobbies", "List of schools", "List of newspapers"],
    answer: 0,
    explanation: "The electoral roll contains registered voters for an area."
  },
  {
    question: "Should you share your voting choice if you don't want to?",
    options: ["You must share it", "No, your choice is private", "Only online", "Only with strangers"],
    answer: 1,
    explanation: "Your voting choice is private."
  },
  {
    question: "What is an election manifesto?",
    options: ["A party's plans and promises", "A voter ID", "A polling booth", "A ballot paper"],
    answer: 0,
    explanation: "A manifesto explains a party's proposed policies and plans."
  },
  {
    question: "What should you carry to the polling station?",
    options: ["An accepted identity document", "A campaign poster", "A loudspeaker", "A gift"],
    answer: 0,
    explanation: "Carry an identity document accepted by election authorities."
  },
  {
    question: "What makes a responsible voter?",
    options: ["Making informed decisions", "Following rumours", "Voting under pressure", "Ignoring information"],
    answer: 0,
    explanation: "Responsible voters learn about issues and make their own choices."
  }
];

/* SAMPLE POLLING STATIONS */

const stations = [
  { name: "Community Hall", area: "Madhapur" },
  { name: "Government School", area: "Kukatpally" },
  { name: "Town Hall", area: "Secunderabad" },
  { name: "Public Library", area: "Ameerpet" },
  { name: "Municipal Building", area: "Gachibowli" },
  { name: "Community Centre", area: "Miyapur" },
  { name: "Government College", area: "Begumpet" },
  { name: "Public School", area: "Uppal" }
];

/* MYTHS AND FACTS */

const myths = [
  ["Voting is only for older people.", "Eligible citizens can vote from the age of 18."],
  ["One vote does not matter.", "Every valid vote contributes to the result."],
  ["You must tell others who you voted for.", "Your voting choice is private."],
  ["You can vote without being registered.", "You need to be on the electoral roll."],
  ["Social media posts are always true.", "Check election information with reliable sources."],
  ["Voting is only a right, not a responsibility.", "Informed participation helps strengthen democracy."],
  ["Someone else can decide your vote.", "Your vote is your personal choice."],
  ["You cannot check your voter details.", "Official election services provide voter information."],
  ["All election promises are guaranteed.", "Read manifestos and assess claims carefully."],
  ["You should believe every campaign message.", "Compare information from trustworthy sources."]
];

/* VOTER RIGHTS */

const rights = [
  ["Fair and Free Elections", "Elections should give eligible voters a fair opportunity to participate."],
  ["Secret Ballot", "Your voting choice should remain private."],
  ["Right to Information", "Voters should have access to reliable election information."],
  ["Equal Participation", "Eligible voters should be treated equally."],
  ["Freedom of Choice", "You should be able to make your voting choice without pressure."]
];

let rightIndex = 0;

/* PROGRESS AND XP */

async function saveProgress() {
  localStorage.setItem(STORAGE.progress, JSON.stringify(progress));
  try { await fetch("/api/progress", {method:"PUT", headers:{"Content-Type":"application/json"}, body:JSON.stringify(progress)}); }
  catch (error) { console.error("Progress sync failed", error); }
  updateDashboard();
}

function updateDashboard() {
  document.getElementById("xp").textContent = progress.xp;
  document.getElementById("bestScore").textContent = `${progress.bestScore}/15`;
  document.getElementById("completed").textContent =
    `${progress.completedLessons.length}/6`;
  document.getElementById("badgeCount").textContent = progress.badges.length;

  showAchievements();
}

function addXP(points) {
  progress.xp += points;
  checkBadges();
  saveProgress();
}

function checkBadges() {
  const earned = [];

  if (progress.completedLessons.length >= 1) {
    earned.push("First Step");
  }

  if (progress.completedLessons.length >= 3) {
    earned.push("Knowledge Seeker");
  }

  if (progress.completedLessons.length === 6) {
    earned.push("Lesson Master");
  }

  if (progress.bestScore >= 10) {
    earned.push("Quiz Champion");
  }

  if (progress.bestScore === 15) {
    earned.push("Perfect Score");
  }

  if (progress.practiceVoteDone) {
    earned.push("Practice Voter");
  }

  if (progress.certificateCreated) {
    earned.push("Responsible Citizen");
  }

  progress.badges = [...new Set([...progress.badges, ...earned])];
}

/* LESSONS */

function completeLesson(number) {
  if (progress.completedLessons.includes(number)) {
    alert("You have already completed this lesson!");
    return;
  }

  progress.completedLessons.push(number);
  addXP(10);
  renderLessons();

  alert("Great work! You earned 10 XP.");
}

function renderLessons() {
  document.querySelectorAll("[data-lesson]").forEach(button => {
    const done = progress.completedLessons.includes(
      Number(button.dataset.lesson)
    );

    button.textContent = done ? "✓ Completed" : "Mark as learned";
    button.disabled = done;

    button.closest(".lesson-card").classList.toggle("completed", done);
  });
}

/* QUIZ */

function startQuiz() {
  clearInterval(quizTimer);

  currentQuestion = 0;
  score = 0;
  timeLeft = 900;
  quizFinished = false;

  document.getElementById("startQuizBtn").hidden = true;
  document.getElementById("quizResult").textContent = "";
  document.getElementById("timer").textContent = "15:00";

  showQuestion();

  quizTimer = setInterval(() => {
    timeLeft--;

    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;

    document.getElementById("timer").textContent =
      `${minutes}:${String(seconds).padStart(2, "0")}`;

    if (timeLeft <= 0) {
      finishQuiz();
    }
  }, 1000);
}

function showQuestion() {
  selectedAnswer = false;

  const item = questions[currentQuestion];

  document.getElementById("questionNumber").textContent =
    `Question ${currentQuestion + 1} of ${questions.length}`;

  document.getElementById("question").textContent = item.question;
  document.getElementById("explanation").textContent = "";
  document.getElementById("nextBtn").hidden = true;

  document.getElementById("quizProgress").style.width =
    `${(currentQuestion / questions.length) * 100}%`;

  const area = document.getElementById("answers");
  area.replaceChildren();

  item.options.forEach((option, index) => {
    const button = document.createElement("button");

    button.type = "button";
    button.className = "answer-btn";
    button.textContent = option;

    button.addEventListener("click", () => {
      checkAnswer(index, button);
    });

    area.appendChild(button);
  });
}

function checkAnswer(index, clickedButton) {
  if (selectedAnswer || quizFinished) {
    return;
  }

  selectedAnswer = true;

  const item = questions[currentQuestion];
  const buttons = [...document.querySelectorAll(".answer-btn")];

  buttons.forEach(button => {
    button.disabled = true;
  });

  if (index === item.answer) {
    score++;
    clickedButton.classList.add("correct");
    clickedButton.textContent += " ✓";
  } else {
    clickedButton.classList.add("incorrect");
    clickedButton.textContent += " ✕";

    buttons[item.answer].classList.add("correct");
    buttons[item.answer].textContent += " ✓ Correct answer";
  }

  document.getElementById("explanation").textContent = item.explanation;

  document.getElementById("quizProgress").style.width =
    `${((currentQuestion + 1) / questions.length) * 100}%`;

  document.getElementById("nextBtn").hidden = false;

  document.getElementById("nextBtn").textContent =
    currentQuestion === questions.length - 1
      ? "See results"
      : "Next question →";
}

function nextQuestion() {
  if (!selectedAnswer) {
    return;
  }

  currentQuestion++;

  if (currentQuestion < questions.length) {
    showQuestion();
  } else {
    finishQuiz();
  }
}

function finishQuiz() {
  if (quizFinished) {
    return;
  }

  quizFinished = true;
  clearInterval(quizTimer);

  progress.bestScore = Math.max(progress.bestScore, score);

  document.getElementById("questionNumber").textContent = "Quiz finished";

  document.getElementById("question").textContent =
    "Well done for completing CivicQuest!";

  document.getElementById("answers").replaceChildren();
  document.getElementById("explanation").textContent = "";
  document.getElementById("nextBtn").hidden = true;
  document.getElementById("quizProgress").style.width = "100%";

  document.getElementById("quizResult").textContent =
    `Your score: ${score} out of ${questions.length}`;

  document.getElementById("startQuizBtn").hidden = false;
  document.getElementById("startQuizBtn").textContent = "Try again";

  addXP(score * 10);
}

/* PRACTICE VOTING */

function castPracticeVote() {
  const choice = document.querySelector(
    'input[name="candidate"]:checked'
  );

  const message = document.getElementById("voteMessage");

  if (!choice) {
    message.textContent = "Please choose a practice candidate first.";
    message.style.color = "#bd354b";
    return;
  }

  message.textContent =
    `Your practice vote for Candidate ${choice.value} has been recorded. This is only a simulation.`;

  message.style.color = "#247347";

  if (!progress.practiceVoteDone) {
    progress.practiceVoteDone = true;
    addXP(10);
  }
}

/* POLLING STATION LOCATOR */

async function showStations(searchText = "") {
  const list = document.getElementById("stationList");
  list.replaceChildren();
  try {
    const response = await fetch(`/api/stations?q=${encodeURIComponent(searchText)}`);
    if (!response.ok) throw new Error(describeFailure(response, null, "Station search is unavailable right now. Try again shortly."));
    const data = await response.json();
    if (!data.stations.length) {
      const empty = document.createElement("p");
      empty.textContent = "No matching sample locations found.";
      list.appendChild(empty);
      return;
    }
    data.stations.forEach(station => {
      const card = document.createElement("article");
      card.className = "content-card station-card";
      const heading = document.createElement("h3");
      heading.textContent = station.name;
      const area = document.createElement("p");
      area.textContent = station.area;
      const link = document.createElement("a");
      link.href = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(station.name + " " + station.area)}`;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = "View sample location on map ↗";
      card.append(heading, area, link);
      list.appendChild(card);
    });
  } catch (error) {
    const message = document.createElement("p");
    message.textContent = "Could not load sample locations. Please retry.";
    list.appendChild(message);
    console.error(error);
  }
}

/* MYTH BUSTER */

function showMyths() {
  const list = document.getElementById("mythList");
  list.replaceChildren();

  myths.forEach((myth, index) => {
    const card = document.createElement("article");
    card.className = "content-card myth-card";

    const heading = document.createElement("h3");
    heading.textContent = `Myth ${index + 1}: ${myth[0]}`;

    const fact = document.createElement("p");
    fact.className = "fact";
    fact.textContent = `Fact: ${myth[1]}`;
    fact.hidden = true;

    const button = document.createElement("button");
    button.className = "secondary-btn";
    button.type = "button";
    button.textContent = "Reveal fact";

    button.addEventListener("click", () => {
      fact.hidden = !fact.hidden;
      button.textContent = fact.hidden ? "Reveal fact" : "Hide fact";
    });

    card.append(heading, fact, button);
    list.appendChild(card);
  });
}

/* CERTIFICATE */

function createCertificate() {
  const name = document.getElementById("voterName").value.trim();
  const agreed = document.getElementById("pledgeCheck").checked;

  const message = document.getElementById("certificateMessage");
  const target = document.getElementById("certificate");

  if (!name || !agreed) {
    message.textContent =
      "Please enter your name and accept the pledge first.";

    message.style.color = "#bd354b";
    return;
  }

  progress.certificateCreated = true;
  checkBadges();
  saveProgress();

  const cert = document.createElement("div");
  cert.className = "certificate";

  const kicker = document.createElement("p");
  kicker.className = "cert-kicker";
  kicker.textContent = "BOOTHBUDDY • CIVICQUEST";

  const seal = document.createElement("div");
  seal.className = "cert-seal";
  seal.textContent = "🏅";

  const title = document.createElement("h2");
  title.textContent = "Certificate of Civic Responsibility";

  const presented = document.createElement("p");
  presented.textContent = "This certificate is proudly presented to";

  const recipient = document.createElement("div");
  recipient.className = "cert-name";
  recipient.textContent = name;

  const description = document.createElement("p");

  description.textContent =
    "For taking the Voter Ready Pledge and committing to stay informed, think independently, and participate responsibly in civic life.";

  const date = document.createElement("p");

  date.textContent =
    `Awarded on ${new Date().toLocaleDateString(undefined, {
      year: "numeric",
      month: "long",
      day: "numeric"
    })}`;

  const footer = document.createElement("div");
  footer.className = "cert-footer";

  const left = document.createElement("span");
  left.textContent = "BoothBuddy • CivicQuest";

  const right = document.createElement("span");
  right.textContent = "Learn. Participate. Make a Difference.";

  footer.append(left, right);

  cert.append(
    kicker,
    seal,
    title,
    presented,
    recipient,
    description,
    date,
    footer
  );

  target.replaceChildren(cert);

  const actions = document.createElement("div");
  actions.className = "certificate-actions";

  const printButton = document.createElement("button");
  printButton.className = "primary-btn";
  printButton.type = "button";
  printButton.textContent = "Print / Save as PDF";

  printButton.addEventListener("click", () => {
    window.print();
  });

  actions.appendChild(printButton);
  target.appendChild(actions);

  message.textContent = "Your certificate is ready!";
  message.style.color = "#247347";
}

/* RIGHTS FLASHCARDS */

function nextRight() {
  rightIndex = (rightIndex + 1) % rights.length;

  document.getElementById("rightTitle").textContent =
    rights[rightIndex][0];

  document.getElementById("rightText").textContent =
    rights[rightIndex][1];
}

/* COUNTDOWN */

function updateCountdown() {
  const electionDate =
    new Date("January 1, 2027 00:00:00").getTime();

  const difference = electionDate - Date.now();
  const display = document.getElementById("countdownText");

  if (difference <= 0) {
    display.textContent = "The demo countdown has ended!";
    return;
  }

  const days = Math.floor(difference / 86400000);
  const hours = Math.floor((difference / 3600000) % 24);
  const minutes = Math.floor((difference / 60000) % 60);

  display.textContent =
    `${days} days • ${hours} hours • ${minutes} minutes`;
}

/* ACHIEVEMENTS */

function showAchievements() {
  const list = document.getElementById("achievementList");

  if (!list) {
    return;
  }

  const all = [
    "First Step",
    "Knowledge Seeker",
    "Lesson Master",
    "Quiz Champion",
    "Perfect Score",
    "Practice Voter",
    "Responsible Citizen"
  ];

  const descriptions = {
    "First Step": "Complete your first learning lesson.",
    "Knowledge Seeker": "Complete three learning lessons.",
    "Lesson Master": "Complete all six learning lessons.",
    "Quiz Champion": "Score at least 10 out of 15 in the quiz.",
    "Perfect Score": "Get all 15 quiz questions correct.",
    "Practice Voter": "Complete the practice voting simulation.",
    "Responsible Citizen": "Create your Voter Ready pledge certificate."
  };

  list.replaceChildren();

  all.forEach(badge => {
    const unlocked = progress.badges.includes(badge);

    const card = document.createElement("article");
    card.className = "content-card";

    const title = document.createElement("h3");
    title.textContent = `${unlocked ? "🏅" : "🔒"} ${badge}`;

    const description = document.createElement("p");
    description.textContent = descriptions[badge];

    card.append(title, description);
    list.appendChild(card);
  });
}

/* LOGIN AND APP ACCESS */

function enterApp(profile) {
  document.getElementById("loginScreen").hidden = true;
  document.getElementById("appShell").hidden = false;

  document.getElementById("welcomeUser").textContent =
    `Welcome back, ${profile.name}!`;

  updateDashboard();
  renderLessons();
}

/* Turns a failed response or network error into a message a learner can act on. */
function describeFailure(response, data, fallback) {
  if (!response) return "Cannot reach the server. Check your internet connection and try again.";
  if (data && data.error) return data.error;
  if (response.status === 429) return "Too many attempts. Wait a few minutes and try again.";
  if (response.status >= 500) return "The server had a problem. Please try again in a moment.";
  return fallback;
}

async function initializeLogin() {
  const loginForm = document.getElementById("loginForm");
  const loginMessage = document.getElementById("loginMessage");
  try {
    const response = await fetch("/api/auth/me");
    const data = await response.json();
    if (response.ok && data.user) {
      const saved = await fetch("/api/progress");
      if (saved.ok) progress = {...defaultProgress, ...(await saved.json())};
      enterApp(data.user);
    }
  } catch (error) { loginMessage.textContent = "Server unavailable. Please refresh and try again."; }
  loginForm.addEventListener("submit", async event => {
    event.preventDefault();
    const name = document.getElementById("userName").value.trim();
    const age = Number(document.getElementById("userAge").value);
    const email = document.getElementById("userEmail").value.trim().toLowerCase();
    const password = document.getElementById("userPassword").value;
    if (!name || !Number.isInteger(age) || age < 18 || age > 120) {
      loginMessage.textContent = "You must be 18 or older to use this learning demo."; return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 8) {
      loginMessage.textContent = "Enter a valid email and password (at least 8 characters)."; return;
    }
    loginMessage.textContent = "Creating secure demo account…";
    try {
      let response = await fetch("/api/auth/register", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name,age,email,password})});
      if (response.status === 409) response = await fetch("/api/auth/login", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email,password})});
      const data = await response.json();
      if (!response.ok) throw new Error(describeFailure(response, data, "Unable to sign in."));
      const progressResponse = await fetch("/api/progress");
      if (progressResponse.ok) progress = {...defaultProgress, ...(await progressResponse.json())};
      loginMessage.textContent = "";
      enterApp(data.user);
    } catch (error) { loginMessage.textContent = error instanceof TypeError ? describeFailure(null) : (error.message || "Server error. Try again."); }
  });
}

/* INITIALIZE ALL FEATURES */

function initializeApp() {

  // Dark theme
  document.getElementById("themeBtn").addEventListener("click", () => {
    document.body.classList.toggle("dark");

    localStorage.setItem(
      STORAGE.theme,
      document.body.classList.contains("dark")
        ? "dark"
        : "light"
    );
  });

  if (localStorage.getItem(STORAGE.theme) === "dark") {
    document.body.classList.add("dark");
  }

  // Logout
  document.getElementById("logoutBtn").addEventListener("click", () => {
    fetch("/api/auth/logout", {method:"POST"}).catch(console.error);
    localStorage.removeItem(STORAGE.session);

    document.getElementById("appShell").hidden = true;
    document.getElementById("loginScreen").hidden = false;

    document.getElementById("loginForm").reset();

    document.getElementById("loginMessage").textContent =
      "You have logged out.";

    window.scrollTo(0, 0);
  });

  // Lessons
  document.querySelectorAll("[data-lesson]").forEach(button => {
    button.addEventListener("click", () => {
      completeLesson(Number(button.dataset.lesson));
    });
  });

  // Quiz
  document.getElementById("startQuizBtn")
    .addEventListener("click", startQuiz);

  document.getElementById("nextBtn")
    .addEventListener("click", nextQuestion);

  // Practice voting


  // Polling station search
  document.getElementById("locationSearch")
    .addEventListener("input", event => {
      showStations(event.target.value);
    });

  // Certificate
  document.getElementById("certificateBtn")
    .addEventListener("click", createCertificate);

  // Rights flashcards
  document.getElementById("nextRightBtn")
    .addEventListener("click", nextRight);

  // Load content
  showStations();
  showMyths();
  updateCountdown();
  updateDashboard();
  renderLessons();
}

/* START APPLICATION */

document.addEventListener("DOMContentLoaded", () => {
  initializeApp();
  initializeLogin();
});
