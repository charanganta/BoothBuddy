const KEY = "boothBuddyProgress";
const defaults = Object.freeze({xp:0,bestScore:0,completedLessons:[],badges:[],practiceVoteDone:false,certificateCreated:false});
const listeners = new Set();
function load(){try{return {...defaults,...JSON.parse(localStorage.getItem(KEY)||"{}")};}catch{return {...defaults};}}
let state=load();
function notify(){for(const listener of listeners) listener(state);}
export const store={
 getState:()=>structuredClone(state),
 subscribe(listener){listeners.add(listener);return ()=>listeners.delete(listener);},
 setProgress(next){state={...defaults,...next,completedLessons:[...(next.completedLessons||[])],badges:[...(next.badges||[])]};localStorage.setItem(KEY,JSON.stringify(state));notify();return this.getState();},
 patchProgress(patch){return this.setProgress({...state,...patch});},
 async hydrate(){try{const response=await fetch("/api/progress",{credentials:"same-origin"});if(response.ok){const remote=await response.json();if(remote&&Object.keys(remote).length)this.setProgress(remote);}}catch(error){console.warn("Progress sync deferred; local copy retained.",error);}return this.getState();},
 async sync(){const response=await fetchWithRetry("/api/progress",{method:"PUT",headers:{"Content-Type":"application/json"},credentials:"same-origin",body:JSON.stringify(state)});if(!response.ok)throw new Error("Progress could not be saved to the server.");return response.json();}
};
export async function fetchWithRetry(url,options={},attempts=2){let last;for(let attempt=0;attempt<=attempts;attempt++){try{const response=await fetch(url,options);if(response.status<500||attempt===attempts)return response;last=new Error(`Server error ${response.status}`);}catch(error){last=error;if(attempt===attempts)throw error;}await new Promise(resolve=>setTimeout(resolve,250*(attempt+1)));}throw last;}
