require('dotenv').config();
const config = require('./config');
const logger = require('./logger');
const { openDatabase } = require('./db');
const { createApp } = require('./app');

const db = openDatabase(config.dbFile);
const server = createApp({ db }).listen(config.port, () => logger.info({ port: config.port }, 'BoothBuddy server listening'));

// Graceful shutdown: stop accepting requests, then close the database.
for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => server.close(() => { db.close(); logger.info({ signal }, 'Server stopped'); process.exit(0); }));
}
