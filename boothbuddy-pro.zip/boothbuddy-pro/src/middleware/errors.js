const logger = require('../logger');

/** An error that is safe to show to the client. */
class AppError extends Error {
  constructor(status, code, message, details) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

/** Lets async route handlers throw: rejected promises are forwarded to the error middleware. */
const asyncHandler = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const notFound = (req, res) => res.status(404).json({ error: 'Not found.', code: 'NOT_FOUND' });

// Response shape: { error: "<message>", code: "<MACHINE_CODE>", details?: [...] }.
// `error` stays a plain string so existing clients keep working.
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err);
  if (err.type === 'entity.parse.failed') err = new AppError(400, 'BAD_JSON', 'Request body is not valid JSON.');
  if (err.type === 'entity.too.large') err = new AppError(413, 'TOO_LARGE', 'Request body is too large.');

  const status = Number.isInteger(err.status) ? err.status : 500;
  if (status >= 500) logger.error({ err, requestId: req.id, method: req.method, path: req.path }, 'Unhandled request error');
  else logger.warn({ status, code: err.code, method: req.method, path: req.path }, 'Request rejected');

  res.status(status).json({
    error: status >= 500 ? 'Something went wrong on our side. Please try again.' : err.message,
    code: status >= 500 ? 'INTERNAL' : err.code || 'ERROR',
    ...(status < 500 && err.details ? { details: err.details } : {}),
    ...(status >= 500 ? { requestId: req.id } : {}),
  });
}

module.exports = { AppError, asyncHandler, notFound, errorHandler };
