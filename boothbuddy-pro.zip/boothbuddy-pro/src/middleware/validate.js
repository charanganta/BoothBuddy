const { AppError } = require('./errors');

/** Parses req[source] with a Zod schema and replaces it with the cleaned value. */
const validate = (schema, source = 'body') => (req, res, next) => {
  const result = schema.safeParse(req[source]);
  if (!result.success) {
    const details = result.error.issues.map(issue => ({ field: issue.path.join('.') || '(body)', message: issue.message }));
    const summary = details.map(d => d.message).join(' ');
    return next(new AppError(400, 'VALIDATION', summary, details));
  }
  Object.defineProperty(req, source, { value: result.data, writable: true, configurable: true });
  next();
};

module.exports = { validate };
