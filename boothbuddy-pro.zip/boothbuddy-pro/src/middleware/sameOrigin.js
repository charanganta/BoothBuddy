const { AppError } = require('./errors');

const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

/**
 * CSRF defence in depth, on top of SameSite=Strict cookies: state-changing requests must come from this site.
 * Browsers always send Origin (or Sec-Fetch-Site) on cross-site POSTs, so a forged form on another site is refused.
 */
module.exports = function sameOrigin(req, res, next) {
  if (SAFE_METHODS.has(req.method)) return next();
  const origin = req.get('origin');
  if (origin) {
    let host;
    try { host = new URL(origin).host; } catch { return next(new AppError(403, 'BAD_ORIGIN', 'Request origin is not allowed.')); }
    if (host !== req.get('host')) return next(new AppError(403, 'BAD_ORIGIN', 'Request origin is not allowed.'));
  } else if (req.get('sec-fetch-site') === 'cross-site') {
    return next(new AppError(403, 'BAD_ORIGIN', 'Cross-site requests are not allowed.'));
  }
  next();
};
