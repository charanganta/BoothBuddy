const rateLimit = require('express-rate-limit');
const { AppError } = require('./errors');

/** Builds a limiter that answers with our standard error shape. */
module.exports = (max, windowMs = 15 * 60 * 1000) => rateLimit({
  windowMs,
  limit: max,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  handler: (req, res, next) => next(new AppError(429, 'RATE_LIMITED', 'Too many requests. Wait a few minutes and try again.')),
});
