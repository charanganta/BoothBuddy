const { AppError } = require('./errors');

module.exports = function requireAuth(req, res, next) {
  if (!req.session || !req.session.userId) return next(new AppError(401, 'UNAUTHENTICATED', 'Sign in to continue.'));
  next();
};
