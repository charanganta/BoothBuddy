const path = require('node:path');
const express = require('express');
const helmet = require('helmet');
const session = require('express-session');
const pinoHttp = require('pino-http');
const swaggerUi = require('swagger-ui-express');

const config = require('./config');
const logger = require('./logger');
const openapi = require('./openapi');
const { createSessionStore } = require('./sessionStore');
const { notFound, errorHandler } = require('./middleware/errors');
const sameOrigin = require('./middleware/sameOrigin');
const rateLimit = require('./middleware/rateLimit');
const { SESSION_COOKIE } = require('./routes/auth');

/**
 * Builds the Express app around an open database. Taking dependencies as arguments
 * (instead of requiring a global db) keeps the app testable and ready to swap storage.
 */
function createApp({ db, sessionStore, limits = config.limits } = {}) {
  const services = {
    authService: require('./services/authService')(db),
    progressService: require('./services/progressService')(db),
    stationService: require('./services/stationService')(db),
    practiceVoteService: require('./services/practiceVoteService')(db),
  };

  const app = express();
  app.disable('x-powered-by');
  if (config.isProduction) app.set('trust proxy', 1); // correct client IPs behind a reverse proxy

  app.use(helmet({
    contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'"], imgSrc: ["'self'", 'data:'], objectSrc: ["'none'"], baseUri: ["'self'"], formAction: ["'self'"], frameAncestors: ["'none'"] } },
  }));
  app.use(pinoHttp({ logger, redact: ['req.headers.cookie', 'req.headers.authorization', 'req.body.password', 'res.headers["set-cookie"]'] }));
  app.use(express.json({ limit: '20kb' }));
  app.use(session({
    name: SESSION_COOKIE,
    store: sessionStore || createSessionStore(config.sessionStore),
    secret: config.sessionSecret,
    resave: false,
    saveUninitialized: false,
    rolling: true,
    cookie: { httpOnly: true, sameSite: 'strict', secure: config.isProduction, maxAge: 4 * 60 * 60 * 1000 },
  }));

  app.use('/api', rateLimit(limits.api), sameOrigin);
  app.get('/api/health', (req, res) => {
    try { db.prepare('SELECT 1').get(); res.json({ status: 'ok', service: 'BoothBuddy API' }); }
    catch { res.status(503).json({ status: 'unavailable', service: 'BoothBuddy API' }); }
  });
  app.use('/api/auth', rateLimit(limits.auth), require('./routes/auth')(services));
  app.use('/api/progress', require('./routes/progress')(services));
  app.use('/api/stations', require('./routes/stations')(services));
  app.use('/api/votes', rateLimit(limits.vote, 60 * 1000), require('./routes/votes')(services));
  app.use('/api', notFound);

  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(openapi, { explorer: true }));
  app.get('/api-docs/openapi.json', (req, res) => res.json(openapi));
  app.use(express.static(path.join(__dirname, '..', 'public')));

  app.use(errorHandler);
  return app;
}

module.exports = { createApp };
