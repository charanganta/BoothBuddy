// OpenAPI 3 description served by Swagger UI at /api-docs. Keep in step with src/schemas.js.
const json = schema => ({ required: true, content: { 'application/json': { schema } } });
const reply = description => ({ description });
const errorResponses = { 400: reply('Validation error'), 401: reply('Not signed in'), 403: reply('Cross-site request refused'), 429: reply('Rate limited') };

const credentials = {
  type: 'object', required: ['email', 'password'], additionalProperties: false,
  properties: { email: { type: 'string', format: 'email', maxLength: 254 }, password: { type: 'string', minLength: 8, maxLength: 72 } },
};
const registration = {
  type: 'object', required: ['name', 'age', 'email', 'password'], additionalProperties: false,
  properties: { name: { type: 'string', minLength: 1, maxLength: 60 }, age: { type: 'integer', minimum: 18, maximum: 120 }, ...credentials.properties },
};

module.exports = {
  openapi: '3.0.3',
  info: { title: 'BoothBuddy CivicQuest API', version: '3.0.0', description: 'Learning progress, sample polling-station lookup and a privacy-preserving EVM/VVPAT practice simulator. Educational only; not connected to any election system. Errors use { error, code, details? }.' },
  servers: [{ url: '/' }],
  tags: [{ name: 'Health' }, { name: 'Authentication' }, { name: 'Progress' }, { name: 'Stations' }, { name: 'Voting simulator' }],
  components: {
    securitySchemes: { sessionCookie: { type: 'apiKey', in: 'cookie', name: 'boothbuddy.sid' } },
    schemas: {
      Error: { type: 'object', properties: { error: { type: 'string' }, code: { type: 'string' }, details: { type: 'array', items: { type: 'object' } } } },
      Progress: { type: 'object', additionalProperties: false, properties: { xp: { type: 'integer' }, bestScore: { type: 'integer', maximum: 15 }, completedLessons: { type: 'array', items: { type: 'integer' } }, badges: { type: 'array', items: { type: 'string' } }, practiceVoteDone: { type: 'boolean' }, certificateCreated: { type: 'boolean' } } },
    },
  },
  paths: {
    '/api/health': { get: { tags: ['Health'], summary: 'Liveness and database check', responses: { 200: reply('Healthy'), 503: reply('Database unavailable') } } },
    '/api/auth/register': { post: { tags: ['Authentication'], summary: 'Create an account and sign in', requestBody: json(registration), responses: { 201: reply('Created'), 409: reply('Email already registered'), ...errorResponses } } },
    '/api/auth/login': { post: { tags: ['Authentication'], summary: 'Sign in', requestBody: json(credentials), responses: { 200: reply('Signed in'), ...errorResponses } } },
    '/api/auth/me': { get: { tags: ['Authentication'], summary: 'Current learner', responses: { 200: reply('Learner'), 401: reply('Not signed in') } } },
    '/api/auth/logout': { post: { tags: ['Authentication'], summary: 'End the session', responses: { 200: reply('Signed out') } } },
    '/api/progress': {
      get: { tags: ['Progress'], summary: 'Read learner progress', security: [{ sessionCookie: [] }], responses: { 200: reply('Progress'), 401: reply('Not signed in') } },
      put: { tags: ['Progress'], summary: 'Validate and save learner progress', security: [{ sessionCookie: [] }], requestBody: json({ $ref: '#/components/schemas/Progress' }), responses: { 200: reply('Saved'), ...errorResponses } },
    },
    '/api/stations': { get: { tags: ['Stations'], summary: 'Search fictional sample stations', parameters: [
      { in: 'query', name: 'q', schema: { type: 'string', maxLength: 80 } },
      { in: 'query', name: 'limit', schema: { type: 'integer', minimum: 1, maximum: 50, default: 20 } },
      { in: 'query', name: 'offset', schema: { type: 'integer', minimum: 0, default: 0 } }], responses: { 200: reply('{ stations, total, demo }'), 400: reply('Validation error') } } },
    '/api/votes': { post: { tags: ['Voting simulator'], summary: 'Complete a practice cycle', description: 'The candidate is validated and discarded. Only an anonymous, hash-chained completion event is stored.', security: [{ sessionCookie: [] }], requestBody: json({ type: 'object', required: ['candidate'], additionalProperties: false, properties: { candidate: { type: 'string', enum: ['A', 'B', 'C', 'NOTA'] } } }), responses: { 201: reply('Practice cycle completed'), ...errorResponses } } },
    '/api/votes/audit': { get: { tags: ['Voting simulator'], summary: 'Verify the anonymous audit hash chain', responses: { 200: reply('{ valid, entries, brokenAtEntry? }') } } },
  },
};
