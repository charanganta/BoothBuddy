const fs = require('node:fs');
const path = require('node:path');
const Database = require('better-sqlite3');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT    NOT NULL,
  age           INTEGER NOT NULL,
  email         TEXT    NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT    NOT NULL,
  created_at    TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS progress (
  user_id    INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  payload    TEXT    NOT NULL DEFAULT '{}',
  updated_at TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP
);
-- PRIVACY BY DESIGN: the audit trail has no user id, no candidate and no timestamp,
-- so a completed practice cycle cannot be traced to a person or a choice.
-- Each row is chained to the previous one by a SHA-256 hash to make tampering detectable.
CREATE TABLE IF NOT EXISTS practice_audit (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  event     TEXT NOT NULL CHECK (event = 'practice_cycle_completed'),
  nonce     TEXT NOT NULL,
  prev_hash TEXT NOT NULL,
  hash      TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS stations (
  id   INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  area TEXT NOT NULL
);
`;

const SAMPLE_STATIONS = [
  ['Community Hall', 'Madhapur'], ['Government School', 'Kukatpally'], ['Town Hall', 'Secunderabad'],
  ['Public Library', 'Ameerpet'], ['Municipal Building', 'Gachibowli'], ['Community Centre', 'Miyapur'],
  ['Government College', 'Begumpet'], ['Public School', 'Uppal'],
];

function seedStations(db) {
  if (db.prepare('SELECT COUNT(*) AS n FROM stations').get().n > 0) return;
  const insert = db.prepare('INSERT INTO stations(name, area) VALUES (?, ?)');
  db.transaction(() => SAMPLE_STATIONS.forEach(row => insert.run(...row)))();
}

/** Opens (and if needed creates) the database. Pass ':memory:' for tests. */
function openDatabase(file = path.join(process.cwd(), 'data', 'boothbuddy.sqlite')) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new Database(file);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.exec(SCHEMA);
  seedStations(db);
  return db;
}

module.exports = { openDatabase };
