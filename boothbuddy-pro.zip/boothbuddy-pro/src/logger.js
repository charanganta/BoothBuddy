const pino = require('pino');

module.exports = pino({
  level: process.env.LOG_LEVEL || (process.env.NODE_ENV === 'production' ? 'info' : 'debug'),
  redact: {
    paths: ['req.headers.cookie', 'req.headers.authorization', 'password', 'password_hash', 'req.body.password', 'res.headers["set-cookie"]'],
    censor: '[REDACTED]',
  },
  base: { service: 'boothbuddy-api', environment: process.env.NODE_ENV || 'development' },
  timestamp: pino.stdTimeFunctions.isoTime,
});
