const express = require('express');
const schemas = require('../schemas');
const { validate } = require('../middleware/validate');

module.exports = ({ stationService }) => {
  const router = express.Router();
  router.get('/', validate(schemas.stationQuery, 'query'), (req, res) => {
    res.set('Cache-Control', 'public, max-age=60'); // sample data changes rarely
    res.json({ ...stationService.search(req.query), demo: true });
  });
  return router;
};
