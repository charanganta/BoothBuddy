const express = require('express');
const schemas = require('../schemas');
const requireAuth = require('../middleware/auth');
const { validate } = require('../middleware/validate');

module.exports = ({ progressService }) => {
  const router = express.Router();
  router.use(requireAuth);
  router.get('/', (req, res) => res.json(progressService.get(req.session.userId)));
  router.put('/', validate(schemas.progress), (req, res) => {
    res.json({ ok: true, progress: progressService.save(req.session.userId, req.body) });
  });
  return router;
};
