const express = require('express');
const schemas = require('../schemas');
const { validate } = require('../middleware/validate');
const { asyncHandler, AppError } = require('../middleware/errors');

const SESSION_COOKIE = 'boothbuddy.sid';

// Starts a fresh session ID on every sign-in to prevent session fixation.
const startSession = (req, userId) => new Promise((resolve, reject) => {
  req.session.regenerate(err => {
    if (err) return reject(err);
    req.session.userId = userId;
    resolve();
  });
});

module.exports = ({ authService }) => {
  const router = express.Router();

  router.post('/register', validate(schemas.register), asyncHandler(async (req, res) => {
    const user = await authService.register(req.body);
    await startSession(req, user.id);
    res.status(201).json({ user });
  }));

  router.post('/login', validate(schemas.login), asyncHandler(async (req, res) => {
    const user = await authService.authenticate(req.body.email, req.body.password);
    await startSession(req, user.id);
    res.json({ user });
  }));

  router.get('/me', (req, res) => {
    const user = req.session.userId ? authService.getUser(req.session.userId) : null;
    res.status(user ? 200 : 401).json({ user });
  });

  router.post('/logout', (req, res, next) => {
    req.session.destroy(err => {
      if (err) return next(new AppError(500, 'LOGOUT_FAILED', 'Could not end the session.'));
      res.clearCookie(SESSION_COOKIE);
      res.json({ ok: true });
    });
  });

  return router;
};
module.exports.SESSION_COOKIE = SESSION_COOKIE;
