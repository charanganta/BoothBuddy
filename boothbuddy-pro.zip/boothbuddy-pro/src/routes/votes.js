const express = require('express');
const schemas = require('../schemas');
const requireAuth = require('../middleware/auth');
const { validate } = require('../middleware/validate');

module.exports = ({ practiceVoteService }) => {
  const router = express.Router();

  router.post('/', requireAuth, validate(schemas.practiceVote), (req, res) => {
    // Privacy by design: the validated candidate is never read again. Only completion is recorded.
    practiceVoteService.recordCompletedCycle();
    res.status(201).json({ ok: true, receipt: 'DEMO-CYCLE-COMPLETE', message: 'Practice cycle completed. Candidate choice was not stored.' });
  });

  // Public integrity check for the anonymous audit trail.
  router.get('/audit', (req, res) => res.json(practiceVoteService.verifyChain()));

  return router;
};
