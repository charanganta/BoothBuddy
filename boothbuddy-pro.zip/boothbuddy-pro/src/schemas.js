// Single source of truth for request validation. Every schema is strict: unknown fields are rejected.
const { z } = require('zod');

const email = z.string().trim().toLowerCase().email('Enter a valid email address.').max(254);
const password = z.string().min(8, 'Password must be at least 8 characters.').max(72, 'Password must be at most 72 characters.');

const register = z.object({
  name: z.string().trim().min(1, 'Enter your name.').max(60),
  age: z.number().int().min(18, 'You must be 18 or older to use this demo.').max(120),
  email,
  password,
}).strict();

const login = z.object({ email, password }).strict();

const progress = z.object({
  xp: z.number().int().min(0).max(1_000_000),
  bestScore: z.number().int().min(0).max(15),
  completedLessons: z.array(z.number().int().min(1).max(6)).max(6),
  badges: z.array(z.string().max(40)).max(20),
  practiceVoteDone: z.boolean(),
  certificateCreated: z.boolean(),
}).strict();

const CANDIDATES = ['A', 'B', 'C', 'NOTA'];
const practiceVote = z.object({ candidate: z.enum(CANDIDATES, { errorMap: () => ({ message: 'Select a valid demo candidate.' }) }) }).strict();

const stationQuery = z.object({
  q: z.string().trim().max(80).optional().default(''),
  limit: z.coerce.number().int().min(1).max(50).optional().default(20),
  offset: z.coerce.number().int().min(0).max(10_000).optional().default(0),
});

module.exports = { register, login, progress, practiceVote, stationQuery, CANDIDATES };
