const bcrypt = require('bcryptjs');
const { AppError } = require('../middleware/errors');

const BCRYPT_COST = 12;
const DEFAULT_PROGRESS = { xp: 0, bestScore: 0, completedLessons: [], badges: [], practiceVoteDone: false, certificateCreated: false };
// Compared against when the email is unknown so response time does not reveal which emails exist.
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', BCRYPT_COST);

module.exports = function createAuthService(db) {
  const findByEmail = db.prepare('SELECT * FROM users WHERE email = ?');
  const publicUser = db.prepare('SELECT id, name, age, email FROM users WHERE id = ?');

  async function register({ name, age, email, password }) {
    const hash = await bcrypt.hash(password, BCRYPT_COST);
    try {
      return db.transaction(() => {
        const { lastInsertRowid: id } = db.prepare('INSERT INTO users(name, age, email, password_hash) VALUES (?, ?, ?, ?)').run(name, age, email, hash);
        db.prepare('INSERT INTO progress(user_id, payload) VALUES (?, ?)').run(id, JSON.stringify(DEFAULT_PROGRESS));
        return publicUser.get(id);
      })();
    } catch (err) {
      if (String(err.code).startsWith('SQLITE_CONSTRAINT')) throw new AppError(409, 'EMAIL_TAKEN', 'An account with this email already exists.');
      throw err;
    }
  }

  async function authenticate(email, password) {
    const user = findByEmail.get(email);
    const matches = await bcrypt.compare(password, user ? user.password_hash : DUMMY_HASH);
    if (!user || !matches) throw new AppError(401, 'BAD_CREDENTIALS', 'Email or password is incorrect.');
    return publicUser.get(user.id);
  }

  return { register, authenticate, getUser: id => publicUser.get(id) || null };
};
