module.exports = function createProgressService(db) {
  const read = db.prepare('SELECT payload FROM progress WHERE user_id = ?');
  const write = db.prepare(`INSERT INTO progress(user_id, payload, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(user_id) DO UPDATE SET payload = excluded.payload, updated_at = CURRENT_TIMESTAMP`);

  return {
    get(userId) { const row = read.get(userId); return row ? JSON.parse(row.payload) : {}; },
    save(userId, progress) { write.run(userId, JSON.stringify(progress)); return progress; },
  };
};
