const crypto = require('node:crypto');

const GENESIS = 'GENESIS';
const EVENT = 'practice_cycle_completed';
const link = (prevHash, nonce) => crypto.createHash('sha256').update(`${prevHash}|${EVENT}|${nonce}`).digest('hex');

module.exports = function createPracticeVoteService(db) {
  const lastHash = db.prepare('SELECT hash FROM practice_audit ORDER BY id DESC LIMIT 1');
  const insert = db.prepare('INSERT INTO practice_audit(event, nonce, prev_hash, hash) VALUES (?, ?, ?, ?)');

  /**
   * Records that a practice cycle finished. The chosen candidate is deliberately NOT a parameter:
   * the route validates it and throws it away, so it cannot reach storage or logs.
   */
  function recordCompletedCycle() {
    db.transaction(() => {
      const prev = (lastHash.get() || { hash: GENESIS }).hash;
      const nonce = crypto.randomBytes(16).toString('hex');
      insert.run(EVENT, nonce, prev, link(prev, nonce));
    }).immediate();
  }

  /** Recomputes the whole chain; an edited, removed or reordered row makes it invalid. */
  function verifyChain() {
    let prev = GENESIS;
    let count = 0;
    for (const row of db.prepare('SELECT * FROM practice_audit ORDER BY id').iterate()) {
      if (row.prev_hash !== prev || row.hash !== link(prev, row.nonce)) return { valid: false, brokenAtEntry: row.id, entries: count };
      prev = row.hash;
      count += 1;
    }
    return { valid: true, entries: count };
  }

  return { recordCompletedCycle, verifyChain };
};
