// Escape LIKE wildcards so a search for "%" or "_" matches those characters literally.
const escapeLike = text => text.replace(/[\\%_]/g, '\\$&');

module.exports = function createStationService(db) {
  const search = db.prepare(`SELECT id, name, area FROM stations
    WHERE name LIKE @pattern ESCAPE '\\' OR area LIKE @pattern ESCAPE '\\'
    ORDER BY area, id LIMIT @limit OFFSET @offset`);
  const count = db.prepare(`SELECT COUNT(*) AS n FROM stations WHERE name LIKE @pattern ESCAPE '\\' OR area LIKE @pattern ESCAPE '\\'`);

  return {
    search({ q, limit, offset }) {
      const pattern = `%${escapeLike(q)}%`;
      return { stations: search.all({ pattern, limit, offset }), total: count.get({ pattern }).n };
    },
  };
};
