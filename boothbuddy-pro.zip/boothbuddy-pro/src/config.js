// Central place for environment-derived settings so no other module reads process.env directly.
const isProduction = process.env.NODE_ENV === 'production';

function sessionSecret() {
  const secret = process.env.SESSION_SECRET;
  if (secret && secret.length >= 32) return secret;
  if (isProduction) throw new Error('SESSION_SECRET (at least 32 characters) is required in production.');
  return 'local-development-secret-change-before-deploy-32chars';
}

module.exports = {
  isProduction,
  port: Number(process.env.PORT) || 3000,
  dbFile: process.env.DB_FILE,
  sessionStore: process.env.SESSION_STORE || 'sqlite',
  get sessionSecret() { return sessionSecret(); },
  limits: { api: 300, auth: 20, vote: 30 }, // requests per window
};
