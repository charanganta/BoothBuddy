const path = require('node:path');
const session = require('express-session');

/**
 * Session storage seam. SQLite keeps sessions across restarts on a single server.
 * To run several instances, add a shared store here (e.g. connect-redis) and set SESSION_STORE=redis.
 */
function createSessionStore(kind) {
  if (kind === 'memory') return new session.MemoryStore(); // tests only: lost on restart
  const SQLiteStore = require('connect-sqlite3')(session);
  return new SQLiteStore({ db: 'sessions.sqlite', dir: path.join(process.cwd(), 'data') });
}

module.exports = { createSessionStore };
