# Accessibility audit

Automated tools find only part of the problems, so this project uses three layers.

## 1. Automated (every release)
Start the app (`npm start`), then run `npm run a11y` (pa11y-ci with axe + HTML_CodeSniffer, WCAG 2.1 AA). Also run Lighthouse in Chrome DevTools. Fix every error; record warnings below.

## 2. Keyboard-only pass
| Check | Result |
|---|---|
| Skip link reaches main content | |
| Every control reachable and operable with Tab / Shift+Tab / Enter / Space | |
| Visible focus indicator on every control | |
| No keyboard trap (modals, EVM simulator) | |
| EVM flow completable without a mouse | |

## 3. Screen-reader pass (NVDA + Firefox or VoiceOver + Safari)
| Check | Result |
|---|---|
| Landmarks and headings give a sensible outline | |
| Quiz questions and answers are announced with their group label | |
| Simulator status changes (`evmStatus`, VVPAT slip) are announced | |
| Form errors are announced and tied to their fields | |

## 4. Visual
Contrast >= 4.5:1 in light and dark themes, usable at 200% zoom and 320px width, animations respect `prefers-reduced-motion`.

Record date, tester, tool versions and fixes here after each run. Do not claim WCAG conformance until the tables are filled.
