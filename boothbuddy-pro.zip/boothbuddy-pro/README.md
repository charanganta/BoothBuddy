# BoothBuddy CivicQuest — Full-stack edition

A three-tier learning application: browser UI, Express REST API, and SQLite persistence.

## Requirements
- Node.js 20+
- npm 10+

## Run locally
```bash
cp .env.example .env
# Set SESSION_SECRET to a unique random value
npm install
npm start
```
Open http://localhost:3000. The first visit creates an account (18+ demo restriction); subsequent visits can sign in using the same email/password. Never use a real password.

## Architecture
- `public/`: responsive presentation layer (HTML/CSS/JavaScript)
- `src/routes/`: REST endpoints and request validation
- `src/services/`: domain logic and persistence
- `src/db.js`: SQLite schema and prepared statements
- `src/middleware/`: authentication and error handling
- `tests/`: API integration tests

## API documentation
Interactive OpenAPI/Swagger documentation is available at `http://localhost:3000/api-docs`; the machine-readable specification is at `/api-docs/openapi.json`.

## Structured logging
Pino emits JSON logs with timestamps, service/environment metadata, request correlation, and redaction for credentials, cookies, and password fields. Configure `LOG_LEVEL` to control verbosity. Do not log candidate selections or other sensitive learning data.

## Client state management
`public/js/store.js` provides a centralized observable progress store, a single persistence boundary, server hydration, and bounded retry for transient fetch failures. Local progress remains available when the API is temporarily unreachable and can be synchronized when the service returns.

## Accessibility
The interface includes a skip link, visible keyboard focus, live status announcements, descriptive control names, and reduced-motion support. Run `npm run a11y` (pa11y-ci, axe + HTML_CodeSniffer) and complete the manual checklist in `docs/ACCESSIBILITY.md` before release; automated checks do not certify WCAG conformance.

## API
| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/auth/register` | Create account and session |
| POST | `/api/auth/login` | Authenticate |
| GET | `/api/auth/me` | Current session |
| POST | `/api/auth/logout` | End session |
| GET/PUT | `/api/progress` | Read/update learner progress |
| GET | `/api/stations?q=&limit=&offset=` | Search demonstration stations (paginated) |
| POST | `/api/votes` | Execute a practice EVM/VVPAT cycle |
| GET | `/api/votes/audit` | Verify the anonymous hash-chained audit trail |
| GET | `/api/health` | Health check |

## EVM/VVPAT simulator
The training flow models candidate selection, confirmation, a visible VVPAT slip, and a completed-cycle audit event. The server deliberately does **not** store the selected candidate: the audit trail stores only that a demo cycle completed, with no user id or timestamp, and is hash-chained so tampering is detectable. It is not connected to an election system and cannot cast a real vote.

## Security notes
Passwords are hashed with bcrypt; sessions are stored server-side in SQLite; cookies are HttpOnly, SameSite=Strict and Secure in production, with a new session ID on every sign-in; Helmet sets a strict CSP; the whole API is rate limited (auth and vote endpoints more tightly); every request body is validated with strict Zod schemas; cross-origin writes are refused; SQL uses prepared statements with escaped LIKE wildcards. Set HTTPS and `NODE_ENV=production` behind a trusted reverse proxy for deployment. Configure a strong `SESSION_SECRET`.

## Tests
```bash
npm test
```

Set `SESSION_SECRET` to a unique secret of at least 32 characters. Production startup fails if it is missing.
Tests cover registration, login, session protection, progress validation, station search, and vote privacy/audit behavior.

## Docker
```bash
docker build -t boothbuddy . && docker run -p 3000:3000 -e SESSION_SECRET=$(openssl rand -hex 32) -v bb-data:/app/data boothbuddy
```
See `ARCHITECTURE.md` for the scaling path.
