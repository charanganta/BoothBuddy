const { test, after } = require('node:test');
const assert = require('node:assert/strict');
const request = require('supertest');
const { buildApp, newLearner } = require('./helpers');

const { app, db } = buildApp();
after(() => db.close());

test('health endpoint reports ok', async () => {
  const res = await request(app).get('/api/health');
  assert.equal(res.status, 200);
  assert.equal(res.body.status, 'ok');
});

test('security headers are present and the framework is hidden', async () => {
  const res = await request(app).get('/api/health');
  assert.match(res.headers['content-security-policy'], /frame-ancestors 'none'/);
  assert.match(res.headers['content-security-policy'], /script-src 'self'/);
  assert.equal(res.headers['x-content-type-options'], 'nosniff');
  assert.equal(res.headers['x-powered-by'], undefined);
});

test('registration rejects bad input with field-level messages', async () => {
  const res = await request(app).post('/api/auth/register').send({ name: '', age: 17, email: 'nope', password: '123' });
  assert.equal(res.status, 400);
  assert.equal(res.body.code, 'VALIDATION');
  assert.ok(res.body.details.length >= 3);
  assert.equal(typeof res.body.error, 'string');
});

test('registration rejects unknown fields (mass-assignment guard)', async () => {
  const res = await request(app).post('/api/auth/register').send({ ...newLearner(), isAdmin: true });
  assert.equal(res.status, 400);
});

test('register creates a session, /me returns the learner, logout ends it', async () => {
  const agent = request.agent(app);
  const learner = newLearner({ email: 'Mixed.Case@Example.com' });
  const reg = await agent.post('/api/auth/register').send(learner);
  assert.equal(reg.status, 201);
  assert.equal(reg.body.user.email, 'mixed.case@example.com'); // normalised
  assert.equal(reg.body.user.password_hash, undefined);

  assert.equal((await agent.get('/api/auth/me')).body.user.email, 'mixed.case@example.com');
  assert.equal((await agent.post('/api/auth/logout')).status, 200);
  assert.equal((await agent.get('/api/auth/me')).status, 401);
});

test('session cookie is HttpOnly and SameSite=Strict', async () => {
  const res = await request(app).post('/api/auth/register').send(newLearner());
  const cookie = res.headers['set-cookie'].join(';');
  assert.match(cookie, /HttpOnly/i);
  assert.match(cookie, /SameSite=Strict/i);
});

test('passwords are stored as bcrypt hashes', async () => {
  const learner = newLearner();
  await request(app).post('/api/auth/register').send(learner);
  const row = db.prepare('SELECT password_hash FROM users WHERE email = ?').get(learner.email);
  assert.match(row.password_hash, /^\$2[aby]\$12\$/);
  assert.ok(!row.password_hash.includes(learner.password));
});

test('duplicate email returns 409; wrong password and unknown email give the same 401', async () => {
  const learner = newLearner();
  await request(app).post('/api/auth/register').send(learner);
  assert.equal((await request(app).post('/api/auth/register').send(learner)).status, 409);

  const wrong = await request(app).post('/api/auth/login').send({ email: learner.email, password: 'wrong-password' });
  const unknown = await request(app).post('/api/auth/login').send({ email: 'nobody@example.com', password: 'wrong-password' });
  assert.equal(wrong.status, 401);
  assert.equal(unknown.status, 401);
  assert.equal(wrong.body.error, unknown.body.error); // no account enumeration
});

test('login issues a new session id (session fixation defence)', async () => {
  const learner = newLearner();
  await request(app).post('/api/auth/register').send(learner);
  const a = await request(app).post('/api/auth/login').send(learner);
  const b = await request(app).post('/api/auth/login').send(learner);
  assert.notEqual(a.headers['set-cookie'][0].split(';')[0], b.headers['set-cookie'][0].split(';')[0]);
});

test('cross-origin state-changing requests are refused (CSRF)', async () => {
  const res = await request(app).post('/api/auth/login').set('Origin', 'https://evil.example').send(newLearner());
  assert.equal(res.status, 403);
  assert.equal(res.body.code, 'BAD_ORIGIN');
  const sameSite = await request(app).post('/api/auth/login').set('Sec-Fetch-Site', 'cross-site').send(newLearner());
  assert.equal(sameSite.status, 403);
});

test('same-origin requests with an Origin header are allowed', async () => {
  const res = await request(app).post('/api/auth/login').set('Host', 'localhost:3000').set('Origin', 'http://localhost:3000').send({ email: 'x@example.com', password: 'password123' });
  assert.equal(res.status, 401); // reached the handler (bad credentials), not blocked
});

test('malformed JSON and unknown routes return structured errors', async () => {
  const bad = await request(app).post('/api/auth/login').set('Content-Type', 'application/json').send('{oops');
  assert.equal(bad.status, 400);
  assert.equal(bad.body.code, 'BAD_JSON');
  const missing = await request(app).get('/api/nope');
  assert.equal(missing.status, 404);
  assert.equal(missing.body.code, 'NOT_FOUND');
});

test('oversized bodies are rejected', async () => {
  const res = await request(app).post('/api/auth/login').send({ email: 'a@example.com', password: 'x'.repeat(30_000) });
  assert.equal(res.status, 413);
});
