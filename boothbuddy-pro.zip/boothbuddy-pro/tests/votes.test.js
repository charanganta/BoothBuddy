const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const request = require('supertest');
const { buildApp, newLearner } = require('./helpers');

const { app, db } = buildApp();
let agent;
before(async () => { agent = request.agent(app); await agent.post('/api/auth/register').send(newLearner()); });
after(() => db.close());

test('practice vote requires sign-in and a valid candidate', async () => {
  assert.equal((await request(app).post('/api/votes').send({ candidate: 'A' })).status, 401);
  const bad = await agent.post('/api/votes').send({ candidate: 'X' });
  assert.equal(bad.status, 400);
  assert.equal(bad.body.error, 'Select a valid demo candidate.');
});

test('the chosen candidate is never returned or stored', async () => {
  const res = await agent.post('/api/votes').send({ candidate: 'B' });
  assert.equal(res.status, 201);
  assert.ok(!JSON.stringify(res.body).includes('"B"'));
  const dump = JSON.stringify(db.prepare('SELECT * FROM practice_audit').all());
  assert.ok(!/candidate/i.test(dump));
});

test('privacy by design: audit rows carry no user id, candidate or timestamp', () => {
  const cols = db.prepare('PRAGMA table_info(practice_audit)').all().map(c => c.name);
  assert.deepEqual(cols, ['id', 'event', 'nonce', 'prev_hash', 'hash']);
});

test('audit hash chain verifies, then detects tampering and deletion', async () => {
  await agent.post('/api/votes').send({ candidate: 'A' });
  await agent.post('/api/votes').send({ candidate: 'NOTA' });
  const ok = await request(app).get('/api/votes/audit');
  assert.equal(ok.body.valid, true);
  assert.ok(ok.body.entries >= 3);

  db.prepare('UPDATE practice_audit SET nonce = ? WHERE id = 2').run('forged');
  const tampered = await request(app).get('/api/votes/audit');
  assert.equal(tampered.body.valid, false);
  assert.equal(tampered.body.brokenAtEntry, 2);
});

test('OpenAPI spec is served and documents the vote and audit endpoints', async () => {
  const res = await request(app).get('/api-docs/openapi.json');
  assert.equal(res.body.openapi, '3.0.3');
  assert.ok(res.body.paths['/api/votes']);
  assert.ok(res.body.paths['/api/votes/audit']);
});
