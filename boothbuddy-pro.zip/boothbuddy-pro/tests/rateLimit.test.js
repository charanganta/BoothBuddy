const { test, after } = require('node:test');
const assert = require('node:assert/strict');
const request = require('supertest');
const { buildApp } = require('./helpers');

const { app, db } = buildApp({ api: 1000, auth: 3, vote: 2 });
after(() => db.close());

test('auth endpoints are rate limited with a friendly message', async () => {
  const attempt = () => request(app).post('/api/auth/login').send({ email: 'a@example.com', password: 'password123' });
  for (let i = 0; i < 3; i += 1) assert.equal((await attempt()).status, 401);
  const blocked = await attempt();
  assert.equal(blocked.status, 429);
  assert.equal(blocked.body.code, 'RATE_LIMITED');
});
