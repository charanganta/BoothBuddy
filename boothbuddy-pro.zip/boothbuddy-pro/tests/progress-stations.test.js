const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const request = require('supertest');
const { buildApp, newLearner } = require('./helpers');

const { app, db } = buildApp();
let agent;
before(async () => { agent = request.agent(app); await agent.post('/api/auth/register').send(newLearner()); });
after(() => db.close());

const progress = { xp: 20, bestScore: 3, completedLessons: [1, 2], badges: ['First Step'], practiceVoteDone: false, certificateCreated: false };

test('progress requires sign-in', async () => {
  assert.equal((await request(app).get('/api/progress')).status, 401);
  assert.equal((await request(app).put('/api/progress').send(progress)).status, 401);
});

test('progress round-trips and rejects invalid or extra fields', async () => {
  assert.equal((await agent.put('/api/progress').send(progress)).status, 200);
  assert.deepEqual((await agent.get('/api/progress')).body, progress);
  assert.equal((await agent.put('/api/progress').send({ ...progress, bestScore: 99 })).status, 400);
  assert.equal((await agent.put('/api/progress').send({ ...progress, role: 'admin' })).status, 400);
});

test("one learner cannot read another learner's progress", async () => {
  const other = request.agent(app);
  await other.post('/api/auth/register').send(newLearner());
  assert.deepEqual((await other.get('/api/progress')).body.xp, 0);
});

test('station search matches by area and supports pagination', async () => {
  const hit = await request(app).get('/api/stations?q=Madhapur');
  assert.equal(hit.status, 200);
  assert.equal(hit.body.stations[0].area, 'Madhapur');
  assert.equal(hit.body.demo, true);

  const page = await request(app).get('/api/stations?limit=3&offset=0');
  assert.equal(page.body.stations.length, 3);
  assert.equal(page.body.total, 8);
  assert.equal((await request(app).get('/api/stations?limit=999')).status, 400);
});

test('station search treats wildcards and SQL as plain text', async () => {
  assert.equal((await request(app).get('/api/stations?q=%25')).body.stations.length, 0); // "%" is literal
  assert.equal((await request(app).get('/api/stations?q=' + encodeURIComponent("' OR 1=1 --"))).body.stations.length, 0);
  assert.ok((await request(app).get('/api/stations')).body.stations.length > 0);
});
