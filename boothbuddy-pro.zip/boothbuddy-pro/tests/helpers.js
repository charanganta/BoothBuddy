process.env.NODE_ENV = 'test';
process.env.LOG_LEVEL = 'silent';
process.env.SESSION_SECRET = 'test-secret-at-least-32-characters-long';

const session = require('express-session');
const { openDatabase } = require('../src/db');
const { createApp } = require('../src/app');

/** Fresh in-memory database + app for each test file. */
function buildApp(limits) {
  const db = openDatabase(':memory:');
  const app = createApp({ db, sessionStore: new session.MemoryStore(), ...(limits && { limits }) });
  return { db, app };
}

let counter = 0;
const newLearner = (overrides = {}) => ({ name: 'Test Learner', age: 21, email: `learner${++counter}@example.com`, password: 'password123', ...overrides });

module.exports = { buildApp, newLearner };
